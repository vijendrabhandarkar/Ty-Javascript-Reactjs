import React from "react";

function Products() {
  return (
    <div>
      <h1>Product COMPONENT</h1>
    </div>
  );
}

export default Products;
